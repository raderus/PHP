<section id="navigation">
	<nav>
			<ul class="desktop">
				<li><a href="index.php#onama">O NAMA</a></li>
				<li><a href="index.php#proizvodi">ASORTIMAN</a></li>
				<li><a href="index.php#gdje">GDJE KUPITI</a></li>
				<li><a href="index.php" title="HOME"><img src="slike/logo-m.png"></a></li>
				<li><a href="index.php#likovi">NAŠ TIM</a></li>
				<li><a href="index.php#kontakt">KONTAKT</a></li>
				<li><a href="proizvodi.php">PROIZVODI</a></li>
			<div class="clear"></div>
			</ul>
			<span class="cursor" onclick="openNav()">&#9776;</span><span class="logo-mobile"><img src="slike/logo-m.png"></span>
			<ul id="mobile" class="sidenav">
				<li><a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a></li>
				<li><a href="index.php">HOME</a></li>
				<li><a href="index.php#onama">O NAMA</a></li>
				<li><a href="index.php#proizvodi">ASORTIMAN</a></li>
				<li><a href="index.php#gdje">GDJE KUPITI</a></li>
				<li><a href="index.php#likovi">NAŠ TIM</a></li>
				<li><a href="index.php#kontakt">KONTAKT</a></li>
				<li><a href="proizvodi.php">PROIZVODI</a></li>
			<div class="clear"></div>
			</ul>
	</nav>
</section>