<!DOCTYPE html>
<html>
<head>
<title>ZelenJava - Bakinja kuhinja u vašem domu</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/animations.css">
<link rel="stylesheet" href="css/font-awesome.min.css">
<script type="text/javascript" src="css/jquery-2.1.1.min.js"></script>
<script type="text/javascript" src="css/to-top.js"></script>
</head>

<body>
<span id="topy"></span>
<?php include 'navigation.php' ?>
<header>
<div><a href="unos.php">Unos proizvoda</a></div>
<div><a href="reg.php">Registracija</a></div>
<div><a href="login.php">Login</a></div>
	<div class="heading" id="top">
		<img src="slike/logo.png" alt="zelenjava">
		<h4>Bakina kuhinja u vašem domu</h4>
	</div>
</header>
