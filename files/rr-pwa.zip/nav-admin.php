<div class="login"><a class="login" href="unos.php">Unos proizvoda</a></div>
<div class="login"><a href="reg.php">Registracija</a></div>
<div class="login"><a class="login" href="login.php">Admin</a></div>
<div class="clear"></div>
